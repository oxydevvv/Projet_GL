urlpatterns = [
    url(r'^', include(router.urls)),
]